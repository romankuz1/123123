﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace NumberRangeChecker
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CheckButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем число из текстового поля
            if (!int.TryParse(NumberTextBox.Text, out int number))
            {
                ResultTextBlock.Text = "Введите корректное целое число.";
                return; // Прерываем выполнение, если ввод некорректный
            }

            // Проверяем диапазон числа
            if (number >= 0 && number <= 14)
            {
                ResultTextBlock.Text = $"Число {number} принадлежит диапазону [0 - 14]";
            }
            else if (number >= 15 && number <= 35)
            {
                ResultTextBlock.Text = $"Число {number} принадлежит диапазону [15 - 35]";
            }
            else if (number >= 36 && number <= 50)
            {
                ResultTextBlock.Text = $"Число {number} принадлежит диапазону [36 - 50]";
            }
            else if (number >= 51 && number <= 100)
            {
                ResultTextBlock.Text = $"Число {number} принадлежит диапазону [51 - 100]";
            }
            else
            {
                ResultTextBlock.Text = $"Число {number} не принадлежит ни одному из диапазонов.";
            }
        }
    }
}
